
from flask import Flask, request, jsonify
import pytesseract
from PIL import Image
import os
import re

app = Flask(__name__)

UPLOAD_FOLDER = 'static/uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# ✅ Helper function to extract medicine details
def extract_medicine_info(ocr_text):
    medicine_name = re.findall(r'\b[A-Z][A-Za-z]{2,}\b', ocr_text)
    dose = re.findall(r'\b\d{2,4}\s?(mg|MG|Mg|ml|ML|Ml)\b', ocr_text)
    expiry = re.findall(r'(EXP|Exp|exp|Expiry|EXPIRY)[:\s]*([0-9]{2}/[0-9]{2,4})', ocr_text)
    return {
        "medicine_names": medicine_name,
        "dose": dose,
        "expiry_dates": [f'{e[0]}: {e[1]}' for e in expiry]
    }

@app.route('/api/extract', methods=['POST'])
def extract():
    if 'image' not in request.files:
        return jsonify({"error": "No image uploaded"}), 400

    file = request.files['image']
    if file.filename == '':
        return jsonify({"error": "No image selected"}), 400

    filepath = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
    file.save(filepath)

    # ✅ Perform OCR
    ocr_text = pytesseract.image_to_string(Image.open(filepath))

    # ✅ Extract medicine info
    extracted_data = extract_medicine_info(ocr_text)

    return jsonify({
        "ocr_text": ocr_text,
        "medicine_details": extracted_data
    })

if __name__ == '__main__':
    app.run(debug=True, port=5000)
